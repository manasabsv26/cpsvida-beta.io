# drafts folder

You can keep draft news or neuroethics seminar posts here, before moving them to the _posts or _pastsem folder. Once you're ready to post to the site, read https://blog.github.com/2013-03-15-moving-and-renaming-files-on-github/ to see how to move them to the appropriate folder.